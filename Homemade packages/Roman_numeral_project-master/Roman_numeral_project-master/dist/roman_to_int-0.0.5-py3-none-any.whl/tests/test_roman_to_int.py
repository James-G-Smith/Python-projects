from roman_to_int import roman_to_int
def test_roman_to_int():
    assert roman_to_int.roman_to_int("IV" == 4)